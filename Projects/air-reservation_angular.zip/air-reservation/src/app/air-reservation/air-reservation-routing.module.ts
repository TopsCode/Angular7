import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { ReservationListComponent } from './reservation-list/reservation-list.component';

import { ReservationDetailComponent } from './reservation-detail/reservation-detail.component';


const routes: Routes = [

  {path: 'air-reservation', component: ReservationListComponent},
  {path: 'air-reservation/:id', component: ReservationDetailComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AirReservationRoutingModule { }
