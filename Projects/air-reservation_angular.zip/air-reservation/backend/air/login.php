<?php
session_start();
$con=new mysqli("localhost","root","","air");

if(isset($_POST["log"]))

{


    $em=$_POST["em"];
    
    $pass=base64_encode($_POST["pass"]);
    

     $sel="select * from register where email='$em' and password='$pass'";



    $query=mysqli_query($con,$sel);


    $result=mysqli_fetch_array($query);


    $no=mysqli_num_rows($query);



    if($no > 0)



    {


        $_SESSION["rid"]=$result["rid"];

        
        $_SESSION["uname"]=$result["username"];
        $_SESSION["em"]=$result["email"];





    echo "<script>
    
    alert('You are Logged In succefully')


    window.location='flight_booking.php';
    
    
    </script>";
}


else

{



    

    echo "<script>
    
    alert('You email and Password are Wrong try again')


    window.location='http://localhost:4200/login';
    
    
    </script>";



}


}

?>