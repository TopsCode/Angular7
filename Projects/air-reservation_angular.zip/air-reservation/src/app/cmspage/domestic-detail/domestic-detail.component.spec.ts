import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DomesticDetailComponent } from './domestic-detail.component';

describe('DomesticDetailComponent', () => {
  let component: DomesticDetailComponent;
  let fixture: ComponentFixture<DomesticDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DomesticDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DomesticDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
