<?php


session_start();

unset($_SESSION["rid"]);

unset($_SESSION["em"]);


unset($_SESSION["uname"]);




session_destroy();


echo "<script>
    
alert('You are Logout Succefully')


window.location='http://localhost:4200/';


</script>";



?>