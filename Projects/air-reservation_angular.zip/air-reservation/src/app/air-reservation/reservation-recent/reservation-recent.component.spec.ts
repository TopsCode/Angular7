import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservationRecentComponent } from './reservation-recent.component';

describe('ReservationRecentComponent', () => {
  let component: ReservationRecentComponent;
  let fixture: ComponentFixture<ReservationRecentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReservationRecentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReservationRecentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
