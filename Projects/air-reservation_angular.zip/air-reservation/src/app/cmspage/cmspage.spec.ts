import { Cmspage } from './cmspage';

describe('Cmspage', () => {
  it('should create an instance', () => {
    expect(new Cmspage()).toBeTruthy();
  });
});
