import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-international-detail',
  templateUrl: './international-detail.component.html',
  styleUrls: ['./international-detail.component.css']
})
export class InternationalDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
