<?php

session_start();

  
$con=new mysqli("localhost","root","","air");


   



?>



<html>
<head>



    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="bootstrap.min.js"></script>

    <style>

body
{

        background-color:lightblue;


}
    </style>
</head>
<body bgcolor="orange">
<br><br>
  <div class="container-fluid">

    <div class="col-md-12 col-xs-12">

    <h3><span class="glyphicon glyphicon-user"></span> Welcome :<?php echo ucfirst($_SESSION["uname"]);?>              <b style="margin-left:65%"><a href="logout.php">Logout Here! <span class="glyphicon glyphicon-log-out"></span></a></b></h3>   
    <h2 align="center">Your  Booked Ticket Details</h2>

    <hr style="width:50%; border:red solid 3px">
  <div class="col-md-4 col-xs-12">
  <div class="jumbotron" style="background-color: lightblue; box-shadow: 4px 0px 0px 4px white;">


  <hr style="width:90%; border:red solid 3px"> 
   <h4>Your Total Booking Details 
 
   <a href="booking_details.php"><span class="badge badge" style="font-size:24px; background-color:red; color:white">
   



   <?php
   $rid=$_SESSION["rid"];

 $sel="select count(fid) as total from flight_booking where rid='$rid'";


$query=$con->query($sel);


$result=$query->fetch_array();



echo $result["total"];



?>




  </span></a></h4>


<a href="flight_booking.php"><button type="button" class="btn btn-block btn-danger" style="height:50px; font-size:20px">Continue Booking</button></a>
</div>


</div>

    <div class="col-md-8 col-xs-12">

    <div class="jumbotron" style="background-color: lightblue; box-shadow: 4px 0px 0px 4px white;">


            <h4>Total<span class="fa fa-ticket"></span>
 
   <a href="booking_details.php"><span class="badge badge" style="font-size:24px; background-color:red; color:white">
   



   <?php
   $rid=$_SESSION["rid"];

 $sel="select count(fid) as total from flight_booking where rid='$rid'";


$query=$con->query($sel);


$result=$query->fetch_array();



echo $result["total"];



?>




  </span></a></h4>

    <table align="center" border="0" class="table table-responsive" style="font-size:16px">

    <form method="post" class="form-inline">


         <tr>

            <th>Flight Name</th>
            <th>From</th>
            <th>To</th>
            <th>Fight Date</th>
            <th>Price</th>
            <th>Class</th>
            <th>Departue Time</th>
            <th>Action</th>
            


         </tr>

         <?php
   

   $rid=$_SESSION["rid"];
 $sel="select * from flight_booking where rid='$rid'";


$query=$con->query($sel);


while($result=$query->fetch_array())

{





?>


         <tr>

              
           <td><?php echo $result["flight_name"];?></td>   
           
           
           <td><?php echo $result["frm"];?></td>   
               
           <td><?php echo $result["tooo"];?></td>   

           
           <td><?php echo $result["flight_date"];?></td>   

           
           <td><?php echo $result["price"];?></td>   

           
           <td><?php echo $result["class"];?></td>   

           
           <td><?php echo $result["ftime"];?></td>   


           
           <td><a href="invoice.php?bkd=<?php echo $result["fid"];?>"><button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-print"></span>   Print Bill!</button></td>   
           </tr>
    
<?php

}

?>
               

    </form>



    </table>


    </div>
    </div>
  </div>

  </div>

</body>

</html>