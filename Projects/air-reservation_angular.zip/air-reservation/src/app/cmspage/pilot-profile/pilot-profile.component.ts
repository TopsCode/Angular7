import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pilot-profile',
  templateUrl: './pilot-profile.component.html',
  styleUrls: ['./pilot-profile.component.css']
})
export class PilotProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
