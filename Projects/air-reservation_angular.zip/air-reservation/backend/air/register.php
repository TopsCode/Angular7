<?php
session_start();
$con=new mysqli("localhost","root","","air");

if(isset($_POST["reg"]))

{


    $unm=$_POST["uname"];
    
    $em=$_POST["em"];
    
    $pass=base64_encode($_POST["pass"]);
    
    $mob=$_POST["mob"];


    $add=$_POST["address"];





    $insert="insert into register(username,email,password,mobile,address) values('$unm','$em','$pass','$mob','$add')";


    $query=$con->query($insert);

    echo "<script>
    
    alert('Thanks for Create your Account with Airlines Reservation')


    window.location='http://localhost:4200/login';
    
    
    </script>";
}




?>