import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reservation-recent',
  templateUrl: './reservation-recent.component.html',
  styleUrls: ['./reservation-recent.component.css']
})
export class ReservationRecentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
