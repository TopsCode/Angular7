import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PageComponent } from './page/page.component';
import { HistoryComponent } from './history/history.component';
import { NewsComponent } from './news/news.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { DomesticComponent } from './domestic/domestic.component';
import { InternationlComponent } from './internationl/internationl.component';
import { PilotProfileComponent } from './pilot-profile/pilot-profile.component';
import { DomesticDetailComponent } from './domestic-detail/domestic-detail.component';
import { InternationalDetailComponent } from './international-detail/international-detail.component';



const routes: Routes = [

  {path: 'page/:slug', component: PageComponent},
  {path: 'history', component: HistoryComponent},
  
  {path: 'news', component: NewsComponent},
  
  {path: 'testimonials', component: TestimonialsComponent},

  {path: 'contact', component: ContactFormComponent},

  {path: 'login', component: LoginComponent},

  {path: 'registration', component: RegistrationComponent},

  {path: 'domestic', component: DomesticComponent },
  
  {path: 'international', component: InternationlComponent},

  {path: 'pilot-profile', component: PilotProfileComponent},
  {path: 'domestic-detail/:id', component: DomesticDetailComponent},
  {path: 'international-detail/:id', component: InternationalDetailComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CmspageRoutingModule { }
