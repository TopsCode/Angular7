export class Cmspage {



    id: number;
    title: string;
    short_desc: string;
    author: string;
    image: string;
    created_at: Date;


}
