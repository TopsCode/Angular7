<?php

$con=new mysqli("localhost","root","","air");

if(isset($_POST["cont"]))

{


    $nm=$_POST["name"];
    
    $em=$_POST["em"];
    
    $mob=$_POST["mob"];
    
    $message=$_POST["message"];


    $insert="insert into air_contact(name,email,mobile,message) values('$nm','$em','$mob','$message')";


    $query=$con->query($insert);

    echo "<script>
    
    alert('Thanks for Contact Us Our Airline Admin will Contact You Soon')


    window.location='http://localhost:4200/contact';
    
    
    </script>";
}




?>