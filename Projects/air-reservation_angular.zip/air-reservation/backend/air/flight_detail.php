<?php

echo "works fine";

?>