import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternationalDetailComponent } from './international-detail.component';

describe('InternationalDetailComponent', () => {
  let component: InternationalDetailComponent;
  let fixture: ComponentFixture<InternationalDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternationalDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternationalDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
