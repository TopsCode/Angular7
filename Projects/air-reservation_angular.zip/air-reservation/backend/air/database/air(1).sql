-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2019 at 09:34 PM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `air`
--

-- --------------------------------------------------------

--
-- Table structure for table `air_contact`
--

CREATE TABLE `air_contact` (
  `contid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `air_contact`
--

INSERT INTO `air_contact` (`contid`, `name`, `email`, `mobile`, `message`) VALUES
(1, 'brijesh', 'b@gmil.com', 91212121, 'hello'),
(2, 'Ashwini', 'Ashwini@gmail.com', 912121212, 'hello'),
(3, 'brijesh', 'bkpandey.pandey@gmail.com', 912121, 'kk'),
(4, 'ramesh', 'bkpandey.pandey@gmail.com', 9512121, 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `description` text,
  `image` varchar(255) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`id`, `title`, `user_id`, `category_id`, `description`, `image`, `is_featured`, `is_active`, `created_at`) VALUES
(1, 'domestic flight', 1, 1, 'Good services', 'media/f10.jpg', 1, 1, '2019-10-22 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `flight_booking`
--

CREATE TABLE `flight_booking` (
  `fid` int(11) NOT NULL,
  `flight_name` varchar(255) NOT NULL,
  `frm` varchar(255) NOT NULL,
  `tooo` varchar(255) NOT NULL,
  `flight_date` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `class` varchar(255) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `rid` varchar(255) NOT NULL,
  `ftime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight_booking`
--

INSERT INTO `flight_booking` (`fid`, `flight_name`, `frm`, `tooo`, `flight_date`, `price`, `class`, `booking_id`, `rid`, `ftime`) VALUES
(1, 'indigo', 'Ahemdabad', 'Rajkot', '2019-10-24', 10000, 'Economic', 7092, '1', '00:11:16 am'),
(2, 'India Airlines', 'Ahemdabad', 'Rajkot', '2018-08-22', 10000, 'Economic', 11600, '1', '00:20:26 am'),
(3, 'India Airlines', 'Ahemdabad', 'Rajkot', '2018-09-22', 10000, 'Economic', 85117, '1', '00:33:26 am'),
(4, 'airlines', 'Ahemdabad', 'Mumbai', '2018-09-22', 10000, 'Economic', 11165, '2', '01:01:00 am');

-- --------------------------------------------------------

--
-- Table structure for table `pilot_profile`
--

CREATE TABLE `pilot_profile` (
  `pid` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `email` varchar(155) NOT NULL,
  `martus_status` varchar(155) NOT NULL,
  `slary` int(11) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `mother_name` varchar(255) NOT NULL,
  `spuse_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pilot_profile`
--

INSERT INTO `pilot_profile` (`pid`, `name`, `email`, `martus_status`, `slary`, `father_name`, `mother_name`, `spuse_name`) VALUES
(1, 'Surendra ', 'surendra@gmail.com', 'yes', 100000, 'Mr. Kailash Mishra', 'Mrs. Shashi Mishra', 'Mrs. Nidhi Mishra');

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

CREATE TABLE `price` (
  `priceid` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `city` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `price`
--

INSERT INTO `price` (`priceid`, `price`, `city`) VALUES
(1, 10000, 'Ahemdabad'),
(2, 7000, 'Rajkot'),
(3, 8000, 'Mumbai'),
(4, 12500, 'Haidrabad');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `rid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`rid`, `username`, `email`, `password`, `mobile`, `address`) VALUES
(1, 'ashwini', 'ashwini@gmail.com', 'MTIz', 9173357217, '150 feetr ring road rajkot'),
(2, 'bharat', 'bharat@hmail.com', 'MTIz', 915454545454, 'rajkot');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `air_contact`
--
ALTER TABLE `air_contact`
  ADD PRIMARY KEY (`contid`);

--
-- Indexes for table `flight`
--
ALTER TABLE `flight`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flight_booking`
--
ALTER TABLE `flight_booking`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `pilot_profile`
--
ALTER TABLE `pilot_profile`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `price`
--
ALTER TABLE `price`
  ADD PRIMARY KEY (`priceid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`rid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `air_contact`
--
ALTER TABLE `air_contact`
  MODIFY `contid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `flight`
--
ALTER TABLE `flight`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `flight_booking`
--
ALTER TABLE `flight_booking`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pilot_profile`
--
ALTER TABLE `pilot_profile`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `price`
--
ALTER TABLE `price`
  MODIFY `priceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
