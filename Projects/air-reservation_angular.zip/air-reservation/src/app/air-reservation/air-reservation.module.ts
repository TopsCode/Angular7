import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AirReservationRoutingModule } from './air-reservation-routing.module';
import { ReservationFeaturedComponent } from './reservation-featured/reservation-featured.component';
import { ReservationListComponent } from './reservation-list/reservation-list.component';
import { ReservationDetailComponent } from './reservation-detail/reservation-detail.component';
import { ReservationRecentComponent } from './reservation-recent/reservation-recent.component';
import { CategoriesComponent } from './categories/categories.component';


@NgModule({
  declarations: [ReservationFeaturedComponent, ReservationListComponent, ReservationDetailComponent, ReservationRecentComponent, CategoriesComponent],
  imports: [
    CommonModule,
    AirReservationRoutingModule
  ],
  exports: [
    ReservationFeaturedComponent
  ],
  
})
export class AirReservationModule {  }
