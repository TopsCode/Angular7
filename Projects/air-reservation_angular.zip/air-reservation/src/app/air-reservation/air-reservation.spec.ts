import { AirReservation } from './air-reservation';

describe('AirReservation', () => {
  it('should create an instance', () => {
    expect(new AirReservation()).toBeTruthy();
  });
});
