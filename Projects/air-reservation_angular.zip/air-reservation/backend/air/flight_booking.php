<?php

session_start();

$con=new mysqli("localhost","root","","air");

if(isset($_POST["book"]))

{

   
    date_default_timezone_set("asia/calcutta");


    $fnm=$_POST["fname"];
    
    $frm=$_POST["from"];
    
    $to=$_POST["too"];

    $fd=$_POST["fd"];

    $price=$_POST["price"];
    
    $cls=$_POST["cls"];

    
    $id=rand(00000,99999);

    

    $rid=$_SESSION["rid"];


    $ftime=date('H:i:s a');



      $insert="insert into flight_booking(flight_name,frm,tooo,flight_date,price,class,booking_id,rid,ftime) values('$fnm','$frm','$to','$fd','$price','$cls','$id','$rid','$ftime')";


    


    $query=$con->query($insert);

   echo "<script>
    
    alert('Your Flight Booked Suucefully Please Print Your Invoive For Travel')


    window.location='booking_details.php';
    
    
    </script>";
}




?>



<html>
<head>



    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="bootstrap.min.js"></script>

    <style>

body
{

        background-color:lightblue;


}
    </style>
</head>
<body bgcolor="orange">
<br><br>
  <div class="container-fluid">

    <div class="col-md-12 col-xs-12">

    <h3><span class="glyphicon glyphicon-user"></span> Welcome :<?php echo ucfirst($_SESSION["uname"]);?>              <b style="margin-left:65%"><a href="logout.php">Logout Here! <span class="glyphicon glyphicon-log-out"></span></a></b></h3>   
    

  <hr style="width:100%; border:red solid 3px"> 


  <div class="col-md-4 col-xs-12">

  <div class="jumbotron" style="background-color: lightblue; box-shadow: 4px 0px 0px 4px white;">



   <h3>Your Total Booking 
   <a href="booking_details.php"><span class="badge badge" style="font-size:24px; background-color:red; color:white">
   



<?php
   $rid=$_SESSION["rid"];

 $sel="select count(fid) as total from flight_booking where rid='$rid'";


$query=$con->query($sel);


$result=$query->fetch_array();



echo $result["total"];



?>




  </span></a></h3>



</div>


</div>

    <div class="col-md-8 col-xs-12">

        
        <div class="jumbotron" style="background-color: lightblue; box-shadow: 4px 0px 0px 4px white;">

              
    <h3 align="center">Book Your Flight Here</h3>
    

    <hr style="width:50%; border:red solid 3px"> 
    <table align="center" border="0" class="table table-responsive">

    <form method="post" class="form-inline">


         <tr>

            <th>Flight Name</th>

            <td><input type="text" name="fname" required class="form-control"></td>

         </tr>


         <tr>

                <th>From</th>
    
                <td>
                    
                    
                    <select name="from"  required class="form-control">

                        <option value="">-select Location-</option>

                     
 
                   

                        <option value="Ahemdabad">Ahemdabad</option>
                        
                        <option value="Rajkot">Rajkot</option>

                        <option value="Mumbai">Mumbai</option>

                        <option value="Haidrabad">Haidrabad</option>


                        </select>




                   </td>
       
    
             </tr>




          
         <tr>

                <th>To</th>
    
                <td>
                    
                    
                    <select name="too"  required class="form-control">

                        <option value="">-select Location-</option>

                        <option value="Ahemdabad">Ahemdabad</option>
                        
                        <option value="Rajkot">Rajkot</option>

                        <option value="Mumbai">Mumbai</option>

                        <option value="Haidrabad">Haidrabad</option>

                        </select>



                        
                   </td>
       
    
             </tr>



             <tr>

<th>Booking Date</th>

<td><input type="date" name="fd" required class="form-control"></td>

</tr>


           


                     <tr>

                            <th>Price</th>
                
                            <td>Rs.<input type="text" name="price"  value="10000" required class="form-control"></td>
                
                         </tr>




                         
                 <tr>

                        <th>Select Class</th>
            
                        <td><select name="cls"  required class="form-control">

                             <option value="">-select class-</option>

                             <option value="Economic">Economi</option>
                             
                             <option value="International">International</option>

                             </select>


                        </td>
            
                     </tr>





                     <tr>

                            <th style="color:red; font-size:20px">For Procced To Payment Please Enter Card Details :</th>
                
                           
                
                         </tr>

                     

                         <tr>

<th>Card Number XXX</th>

<td><input type="text" name="card"  placeholder="Enter Card Number for Payment" required class="form-control"></td>

</tr>



<tr>

<th>Card CVV Number</th>

<td><input type="text" name="cvv"  placeholder="Enter Cvv" required class="form-control"></td>

</tr>

                     <tr>

                            
                
                            <td align="right" colspan="2"><input type="submit" name="book" class="btn btn-lg btn-success" value="Book Your  Flight"></td>
                
                         </tr>


    </form>



    </table>


    </div>
    </div>
  </div>

  </div>

</body>

</html>