import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reservation-featured',
  templateUrl: './reservation-featured.component.html',
  styleUrls: ['./reservation-featured.component.css']
})
export class ReservationFeaturedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
