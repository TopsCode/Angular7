import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternationlComponent } from './internationl.component';

describe('InternationlComponent', () => {
  let component: InternationlComponent;
  let fixture: ComponentFixture<InternationlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternationlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternationlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
