<?php
session_start();
$con=new mysqli("localhost","root","","air");

if(isset($_REQUEST["bkd"]))

{


    $rid=$_SESSION["rid"];

    $bkd=$_REQUEST["bkd"];


    $sel="select flight_booking.*, username from flight_booking join register on register.rid=flight_booking.rid  where fid='$bkd' "; 


   $query=$con->query($sel);


$result=$query->fetch_array();

}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Print Invoice</title>
    <link rel="stylesheet" href="style.css" media="all" />


    <script>
   


   function bill()

   {


     window.print();


   }


</script>
  </head>
  <body>

  
      <h2><span class="glyphicon glyphicon-user"></span> Welcome :<?php echo ucfirst($_SESSION["uname"]);?>              <b style="margin-left:65%"><a href="logout.php">Logout Here! <span class="glyphicon glyphicon-log-out"></span></a></b></h2>   



  <hr style="border:1px solid green; width:100%">
            
    <header class="clearfix" style="width:100%">
      <div id="logo">
        <img src="logo.png">
      </div>
      <h1>INVOICE Of Your Booking</h1>
      <div id="company" class="clearfix">
        <div>Airlines India Pvt ltd</div>
        <div>150 Feet ring road<br /> Rajkot</div>
        
        <div><a href="mailto:info@airlines.com">info@airlines.com</a></div>
      </div>
     
    </header>
    <main>
      <table>
       
          <tr style="font-size:15px; font-weight: bold !important;">

          <th class="service">Passenger Name</th>
            <th class="service">Flight Name</th>
            
           
            <th>From</th>
            <th>To</th>
            <th>Travel Date</th>
            <th>Departure Time</th>
            <th>Class</th>
            <th>TOTAL</th>

          </tr>
        
          <tr>
          <td class="service"><?php  echo $result["username"];?></td>
            <td class="service"><?php  echo $result["flight_name"];?></td>
            <td class="desc"><?php  echo $result["frm"];?></td>
            <td class="unit"><?php  echo $result["tooo"];?></td>
            <td class="qty"><?php  echo $result["flight_date"];?></td>
            <td class="qty"><?php  echo $result["ftime"];?></td>
            <td class="total"><?php  echo $result["class"];?></td>
            <td class="total"><?php  echo $result["price"];?></td>
          </tr>
        
          <tr>
            <td colspan="7" style="font-size:25px; color:green">SUBTOTAL</td>

        
            <td class="total" style="font-size:25px; color:green">-<?php  echo $result["price"];?>-/</td>
          </tr>
         
         

          <tr>


          <td colspan="8"><button type="button" style="background-color:red; width:300px; height:50px; border:none; color:white; font-size:20px; letter-spacing: 2px;"  onclick="bill()" >Print Invoice</button></td>

</tr>
       
      </table>
     
    </main>
    
  </body>
</html>