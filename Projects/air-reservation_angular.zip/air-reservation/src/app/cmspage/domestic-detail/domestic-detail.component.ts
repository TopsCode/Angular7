import { Component, OnInit } from '@angular/core';
// import { CmspageService } from '../cmspage.service';
// import { Title } from '@angular/platform-browser';


@Component({
  selector: 'app-domestic-detail',
  templateUrl: './domestic-detail.component.html',
  styleUrls: ['./domestic-detail.component.css']
})
export class DomesticDetailComponent implements OnInit {

  // title = 'cmspage';
  // Cmspage: 'cmspage';
  // error: {};

  constructor() { }

  ngOnInit() {

  
  
  }
}
