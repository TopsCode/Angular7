import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CmspageRoutingModule } from './cmspage-routing.module';
import { PageComponent } from './page/page.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { NewsComponent } from './news/news.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { HistoryComponent } from './history/history.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { DomesticComponent } from './domestic/domestic.component';
import { InternationlComponent } from './internationl/internationl.component';
import { PilotProfileComponent } from './pilot-profile/pilot-profile.component';
import { DomesticDetailComponent } from './domestic-detail/domestic-detail.component';
import { InternationalDetailComponent } from './international-detail/international-detail.component';


@NgModule({
  declarations: [PageComponent, ContactFormComponent, NewsComponent, TestimonialsComponent, HistoryComponent, LoginComponent, RegistrationComponent, DomesticComponent, InternationlComponent, PilotProfileComponent, DomesticDetailComponent, InternationalDetailComponent],
  imports: [
    CommonModule,
    CmspageRoutingModule
  ]
})
export class CmspageModule { }
