import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-internationl',
  templateUrl: './internationl.component.html',
  styleUrls: ['./internationl.component.css']
})
export class InternationlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
